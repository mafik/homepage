
mergeInto(LibraryManager.library, {
  ScoreExternal: function (id_name_ptr, gender_ptr, has_t1, has_t2, has_t3,
    has_t4, type1_ptr, type2_ptr, flying, nocturnal,
    kindling, watering, planting, electric, handiwork,
    gathering, lumbering, mining, medicine, cooling,
    transporting, farming, food_requirement, hp, melee,
    shot, defence, stamina, mount_speed,
    transport_speed) {
    let id_name = UTF8ToString(id_name_ptr);
    let gender = UTF8ToString(gender_ptr);
    let type1 = UTF8ToString(type1_ptr);
    let type2 = UTF8ToString(type2_ptr);
    let score = Score(
      id_name,
      gender,
      has_t1 != 0, has_t2 != 0, has_t3 != 0, has_t4 != 0,
      type1, type2,
      flying != 0,
      nocturnal != 0,
      kindling, watering, planting, electric,
      handiwork, gathering, lumbering, mining,
      medicine, cooling, transporting, farming,
      food_requirement,
      hp, melee, shot, defence, stamina,
      mount_speed, transport_speed,
      speed_multiplier, work_speed_multiplier, hunger_multiplier, sanity_multiplier);
    return score;
  }
});