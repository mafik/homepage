#include "score.cc"
#include <set>

struct RoosterEntry {
  Pal pal;
  PalOrigin origin;
};

vector<Pal> initial_pals;

struct CompactRoosterEntry {
  Pal pal;
  // 2 bytes of padding
  int parent1;
  int parent2;
  float attempts;
};

vector<CompactRoosterEntry> compact_rooster;

struct BestPalsEntry {
  uint32_t rooster_index = 0xffffffff;
  float score = 0;
};

vector<BestPalsEntry> best_pals;

Rooster rooster;

static void ExportRooster() {
  compact_rooster.resize(rooster.size());
  phmap::flat_hash_map<Pal, int> pal_to_index;
  int i = 0;
  for (auto &[pal, origin] : rooster) {
    pal_to_index[pal] = i++;
  }
  for (auto &[pal, origin] : rooster) {
    int child = pal_to_index[pal];
    int parent1 = pal_to_index[origin.parent1];
    int parent2 = pal_to_index[origin.parent2];
    compact_rooster[child] = {pal, parent1, parent2, origin.attempts};
  }
}

phmap::flat_hash_set<Pal> parents_queue;
vector<RoosterEntry> add_to_rooster;
phmap::flat_hash_map<Pal, float> children;

float (*ScoreFn)(Pal pal);

struct BreedStatus {
  int iter = 0;
  int parents_queue_size;
  int rooster_size;
} breed_status;

static BreedStatus *BreedStart() {
  parents_queue.clear();
  add_to_rooster.clear();
  children.clear();
  rooster.clear();
  for (auto pal : initial_pals) {
    parents_queue.emplace(pal);
    rooster[pal] = {pal, pal, 0};
  }
  breed_status.iter = 0;
  breed_status.parents_queue_size = parents_queue.size();
  breed_status.rooster_size = rooster.size();
  return &breed_status;
}

static void ScorePals() {
  best_pals.clear();

  vector<float> scores;
  vector<uint32_t> sort_by_score;
  scores.reserve(compact_rooster.size());
  sort_by_score.reserve(compact_rooster.size());
  for (int i = 0; i < compact_rooster.size(); ++i) {
    scores.push_back(ScoreFn(compact_rooster[i].pal));
    sort_by_score.push_back(i);
  }

  auto sort_by_score_fn = [&](int a, int b) {
    if (scores[a] == scores[b]) {
      return compact_rooster[a].attempts <
             compact_rooster[b].attempts; // ascending attempts
    }
    return scores[a] > scores[b]; // descending score
  };
  sort(sort_by_score.begin(), sort_by_score.end(), sort_by_score_fn);

  phmap::flat_hash_set<Pal> visited;
  int best_score_i = 0;
  while (best_score_i < compact_rooster.size()) {
    uint32_t i = sort_by_score[best_score_i];
    if (scores[i] <= 0.0f) {
      break;
    }
    Pal pal = compact_rooster[i].pal;
    Pal opposite = {pal.id, Opposite(pal.gender), pal.traits};
    if (visited.contains(pal) || visited.contains(opposite)) {
      best_score_i++;
      continue;
    }
    visited.insert(pal);
    visited.insert(opposite);
    if (!best_pals.empty()) {
      if (compact_rooster[i].attempts >=
          compact_rooster[best_pals.back().rooster_index].attempts) {
        best_score_i++;
        continue;
      }
    }
    best_pals.emplace_back(i, scores[i]);
  }
}

extern "C" BreedStatus *BreedStep(int max_steps) {
  for (int step = 0; !parents_queue.empty() && step < max_steps; ++step) {
    breed_status.iter++;
    auto a_it = [&]() {
      auto best_it = parents_queue.begin();
      for (auto it = parents_queue.begin(); it != parents_queue.end(); ++it) {
        if (rooster[*it].attempts < rooster[*best_it].attempts) {
          best_it = it;
        }
      }
      return best_it;
    }();
    auto a = *a_it;
    parents_queue.erase(a_it);
    add_to_rooster.clear();
    for (auto &b_it : rooster) {
      Pal b = b_it.first;
      if (b == a) {
        continue;
      }
      float parent_attempts = rooster[a].attempts + rooster[b].attempts;
      children.clear();
      Cross(a, b, children);

      for (auto [child, attempts] : children) {
        // Actual number of attempts must account for the attempts to create
        // parents
        float total_attempts = parent_attempts + attempts;
        // if (total_attempts > MaxAttempts) {
        //   continue;
        // }
        if (auto child_it = rooster.find(child); child_it != rooster.end()) {
          if (child_it->second.attempts > total_attempts) {
            // We've found a better path for this Pal!
            add_to_rooster.emplace_back(child, PalOrigin{a, b, total_attempts});
          }
        } else {
          add_to_rooster.emplace_back(child, PalOrigin{a, b, total_attempts});
        }
      }
    }
    for (auto &[pal, origin] : add_to_rooster) {
      bool added = false;
      if (auto pal_it = rooster.find(pal); pal_it != rooster.end()) {
        if (pal_it->second.attempts > origin.attempts) {
          // We've found a better path for this Pal!
          pal_it->second = origin;
          added = true;
        }
      } else {
        rooster.emplace(pal, origin);
        added = true;
      }
      if (added) {
        // If the new child was added to the rooster, also try to use it as a
        // parent next
        parents_queue.emplace(pal);
      }
    }
  }
  if (parents_queue.empty()) {
    ExportRooster();
    ScorePals();
  }

  breed_status.parents_queue_size = parents_queue.size();
  breed_status.rooster_size = rooster.size();
  return &breed_status;
}

extern "C" Pal *ReservePalArray(int n) {
  initial_pals.resize(n);
  return initial_pals.data();
}

extern "C" uint32_t RoosterSize() { return compact_rooster.size(); }

extern "C" CompactRoosterEntry *RoosterData() { return compact_rooster.data(); }

extern "C" uint32_t BestPalsSize() { return best_pals.size(); }

extern "C" BestPalsEntry *BestPalsData() { return best_pals.data(); }

struct Metric {
  const char *name;
  float (*Fn)(Pal pal);
  span<Trait> best_traits;
} metrics[] = {
    {"Mount", ScoreMount, kBestTraitsForMount},
    {"Kindling", ScoreKindling, kBestTraitsForWorker},
    {"Watering", ScoreWatering, kBestTraitsForWorker},
    {"Planting", ScorePlanting, kBestTraitsForWorker},
    {"Electric", ScoreElectric, kBestTraitsForWorker},
    {"Handiwork", ScoreHandiwork, kBestTraitsForWorker},
    {"Gathering", ScoreGathering, kBestTraitsForWorker},
    {"Lumbering", ScoreLumbering, kBestTraitsForWorker},
    {"Mining", ScoreMining, kBestTraitsForWorker},
    {"Medicine", ScoreMedicine, kBestTraitsForWorker},
    {"Cooling", ScoreCooling, kBestTraitsForWorker},
    {"Transporting", ScoreTransporting, kBestTraitsForTransporting},
    {"Wool Farming", ScoreWool, kBestTraitsForFarming},
    {"Eggs Farming", ScoreEggs, kBestTraitsForFarming},
    {"Gold Farming", ScoreGold, kBestTraitsForFarming},
    {"Palsphere Farming", ScorePalspheres, kBestTraitsForFarming},
    {"Milk Farming", ScoreMilk, kBestTraitsForFarming},
    {"Cotton Candy Farming", ScoreCottonCandy, kBestTraitsForFarming},
    {"Berry Farming", ScoreBerry, kBestTraitsForFarming},
    {"Honey Farming", ScoreHoney, kBestTraitsForFarming},
    {"Flame Organ Farming", ScoreFlameOrgan, kBestTraitsForFarming},
    {"High Quality Cloth Farming", ScoreHighQualityCloth,
     kBestTraitsForFarming},
};

extern "C" uint32_t MetricCount() {
  return sizeof(metrics) / sizeof(metrics[0]);
}

extern "C" const char *MetricName(uint32_t i) { return metrics[i].name; }

extern "C" void BreedStart(int metric) {
  for (int i = 1; i < LastTrait; ++i) {
    BadTraits[i] = true;
  }
  for (auto t : metrics[metric].best_traits) {
    BadTraits[t] = false;
  }
  ScoreFn = metrics[metric].Fn;
  BreedStart();
}

/*
  AddPal(Rushoar, Male, BotanicalBarrier);
  AddPal(Rushoar, Female, Sadist);
  AddPal(Fuddler, Female, Capacitor);
  AddPal(Mau, Female, Ferocious);
  AddPal(Direhowl, Male, Coldblooded);
  AddPal(Tocotoco, Male, Coward);
  AddPal(Tocotoco, Male);
  AddPal(Mozzarina, Female, SuntanLover);
  AddPal(Woolipop, Male);
  AddPal(Caprity, Female, HardSkin);
  AddPal(Melpaca, Male, Hooligan);
  AddPal(Melpaca, Male, Runner);
  AddPal(Melpaca, Female, Brittle);
  AddPal(Eikthyrdeer, Female, BloodOfTheDragon);
  AddPal(Eikthyrdeer, Male, LoggingForeman);
  AddPal(Eikthyrdeer, Male, Vanguard);
  AddPal(Eikthyrdeer, Male, Workaholic);
  AddPal(Eikthyrdeer, Female, Runner);
  AddPal(Eikthyrdeer, Male, Capacitor);
  AddPal(Eikthyrdeer, Male, Aggressive);
  AddPal(Ribbuny, Male, HardSkin);
  AddPal(Ribbuny, Male, BotanicalBarrier);
  AddPal(Incineram, Male, SuntanLover);
  AddPal(Cinnamoth, Male, Nimble);
  AddPal(Arsox, Female, Runner);
  AddPal(Cawgnito, Male, HardSkin);
  AddPal(Cawgnito, Male, Dragonkiller);
  AddPal(Leezpunk, Male, BottomlessStomach, Coward, Sadist);
  AddPal(Leezpunk, Male, Ferocious);
  AddPal(Leezpunk, Male, LoggingForeman);
  AddPal(Beegarde, Female, Conceited, Musclehead, EarthquakeResistant);
  AddPal(Chillet, Female, Vanguard);
  AddPal(Dinossom, Female, DietLover);
  AddPal(Dinossom, Male, Aggressive);
  AddPal(Tombat, Male, Pyromaniac);
  AddPal(Flambelle, Male, Musclehead);
  AddPal(Elphidran, Male, ZenMind);
  AddPal(Anubis, Male, Runner, Pyromaniac);
  AddPal(Univolt, Male, Nimble, BotanicalBarrier, BottomlessStomach);

  // Pals frm base A
  AddPal(Rooby, Female, Nimble);
  AddPal(Vixy, Male, WorkSlave);
  AddPal(Lifmunk, Female);
  AddPal(Chikipi, Male, Nimble);
  AddPal(Pengullet, Female, Ferocious);
  AddPal(Cattiva, Male, Coward, Vanguard);
  AddPal(Dumud, Male, Unstable);
  AddPal(Cremis, Female);
  AddPal(Tanzee, Male, Brave, Serious);
  AddPal(Tanzee, Female);
  AddPal(Tanzee, Male, Swift);
  AddPal(Penking, Female, EarthquakeResistant);

  // Pals from base B
  AddPal(Beegarde, Female, Conceited);
  AddPal(Beegarde, Female, Conceited, ZenMind, Waterproof);
  AddPal(Caprity, Male, DaintyEater);
  AddPal(Caprity, Male, StrongholdStrategist, Waterproof);
  AddPal(Flopie, Male, Conceited);
  AddPal(Chikipi, Female, WorkSlave);
  AddPal(Chikipi, Male, ZenMind, BotanicalBarrier);
  AddPal(Mozzarina, Male, Capacitor);
  AddPal(Mozzarina, Female, DaintyEater, Dragonkiller);
  AddPal(Bushi, Female, Runner, Pyromaniac);
  AddPal(Teafant, Male, Brave);
  AddPal(Broncherry, Female);

  // Pals from team
  AddPal(Vanwyrm, Female, Coldblooded);
  AddPal(Elphidran, Female, Runner, ZenMind, HeatedBody);
  AddPal(Azurobe, Female, Waterproof);
  AddPal(Daedream, Male, StrongholdStrategist);
  AddPal(Dazzi, Male, Cheery);
*/