#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <string>

#include "traits.cc"

using namespace std;

enum Gender : uint8_t { Male, Female };

static const char *ToStr(Gender gender) {
  switch (gender) {
  case Male:
    return "M";
  case Female:
    return "F";
  }
}

static Gender Opposite(Gender gender) {
  switch (gender) {
  case Male:
    return Female;
  case Female:
    return Male;
  }
}

enum ID : uint8_t {
  Lamball,
  Cattiva,
  Chikipi,
  Lifmunk,
  Foxparks,
  Fuack,
  Sparkit,
  Tanzee,
  Rooby,
  Pengullet,
  Penking,
  Jolthog,
  JolthogCryst,
  Gumoss,
  GumossSpecial,
  Vixy,
  Hoocrates,
  Teafant,
  Depresso,
  Cremis,
  Daedream,
  Rushoar,
  Nox,
  Fuddler,
  Killamari,
  Mau,
  MauCryst,
  Celaray,
  Direhowl,
  Tocotoco,
  Flopie,
  Mozzarina,
  Bristla,
  Gobfin,
  GobfinIgnis,
  Hangyu,
  HangyuCryst,
  Mossanda,
  MossandaLux,
  Woolipop,
  Caprity,
  Melpaca,
  Eikthyrdeer,
  EikthyrdeerTerra,
  Nitewing,
  Ribbuny,
  Incineram,
  IncineramNoct,
  Cinnamoth,
  Arsox,
  Dumud,
  Cawgnito,
  Leezpunk,
  LeezpunkIgnis,
  Loupmoon,
  Galeclaw,
  Robinquill,
  RobinquillTerra,
  Gorirat,
  Beegarde,
  Elizabee,
  Grintale,
  Swee,
  Sweepa,
  Chillet,
  Univolt,
  Foxcicle,
  Pyrin,
  PyrinNoct,
  Reindrix,
  Rayhound,
  Kitsun,
  Dazzi,
  Lunaris,
  Dinossom,
  DinossomLux,
  Surfent,
  SurfentTerra,
  Maraith,
  Digtoise,
  Tombat,
  Lovander,
  Flambelle,
  Vanwyrm,
  VanwyrmCryst,
  Bushi,
  Beakon,
  Ragnahawk,
  Katress,
  Wixen,
  Verdash,
  Vaelet,
  Sibelyx,
  Elphidran,
  ElphidranAqua,
  Kelpsea,
  KelpseaIgnis,
  Azurobe,
  Cryolinx,
  Blazehowl,
  BlazehowlNoct,
  Relaxaurus,
  RelaxaurusLux,
  Broncherry,
  BroncherryAqua,
  Petallia,
  Reptyro,
  IceReptyro,
  Kingpaca,
  IceKingpaca,
  Mammorest,
  MammorestCryst,
  Wumpo,
  WumpoBotan,
  Warsect,
  Fenglope,
  Felbat,
  Quivern,
  Blazamut,
  Helzephyr,
  Astegon,
  Menasting,
  Anubis,
  Jormuntide,
  JormuntideIgnis,
  Suzaku,
  SuzakuAqua,
  Grizzbolt,
  Lyleen,
  LyleenNoct,
  Faleris,
  Orserk,
  Shadowbeak,
  Paladius,
  Necromus,
  Frostallion,
  FrostallionNoct,
  Jetragon,
  LastID
};

static const char *ToStr(ID id) {
  switch (id) {
  case Lamball:
    return "Lamball";
  case Cattiva:
    return "Cattiva";
  case Chikipi:
    return "Chikipi";
  case Lifmunk:
    return "Lifmunk";
  case Foxparks:
    return "Foxparks";
  case Fuack:
    return "Fuack";
  case Sparkit:
    return "Sparkit";
  case Tanzee:
    return "Tanzee";
  case Rooby:
    return "Rooby";
  case Pengullet:
    return "Pengullet";
  case Penking:
    return "Penking";
  case Jolthog:
    return "Jolthog";
  case JolthogCryst:
    return "Jolthog Cryst";
  case Gumoss:
    return "Gumoss";
  case GumossSpecial:
    return "Gumoss (Special)";
  case Vixy:
    return "Vixy";
  case Hoocrates:
    return "Hoocrates";
  case Teafant:
    return "Teafant";
  case Depresso:
    return "Depresso";
  case Cremis:
    return "Cremis";
  case Daedream:
    return "Daedream";
  case Rushoar:
    return "Rushoar";
  case Nox:
    return "Nox";
  case Fuddler:
    return "Fuddler";
  case Killamari:
    return "Killamari";
  case Mau:
    return "Mau";
  case MauCryst:
    return "Mau Cryst";
  case Celaray:
    return "Celaray";
  case Direhowl:
    return "Direhowl";
  case Tocotoco:
    return "Tocotoco";
  case Flopie:
    return "Flopie";
  case Mozzarina:
    return "Mozzarina";
  case Bristla:
    return "Bristla";
  case Gobfin:
    return "Gobfin";
  case GobfinIgnis:
    return "Gobfin Ignis";
  case Hangyu:
    return "Hangyu";
  case HangyuCryst:
    return "Hangyu Cryst";
  case Mossanda:
    return "Mossanda";
  case MossandaLux:
    return "Mossanda Lux";
  case Woolipop:
    return "Woolipop";
  case Caprity:
    return "Caprity";
  case Melpaca:
    return "Melpaca";
  case Eikthyrdeer:
    return "Eikthyrdeer";
  case EikthyrdeerTerra:
    return "Eikthyrdeer Terra";
  case Nitewing:
    return "Nitewing";
  case Ribbuny:
    return "Ribbuny";
  case Incineram:
    return "Incineram";
  case IncineramNoct:
    return "Incineram Noct";
  case Cinnamoth:
    return "Cinnamoth";
  case Arsox:
    return "Arsox";
  case Dumud:
    return "Dumud";
  case Cawgnito:
    return "Cawgnito";
  case Leezpunk:
    return "Leezpunk";
  case LeezpunkIgnis:
    return "Leezpunk Ignis";
  case Loupmoon:
    return "Loupmoon";
  case Galeclaw:
    return "Galeclaw";
  case Robinquill:
    return "Robinquill";
  case RobinquillTerra:
    return "Robinquill Terra";
  case Gorirat:
    return "Gorirat";
  case Beegarde:
    return "Beegarde";
  case Elizabee:
    return "Elizabee";
  case Grintale:
    return "Grintale";
  case Swee:
    return "Swee";
  case Sweepa:
    return "Sweepa";
  case Chillet:
    return "Chillet";
  case Univolt:
    return "Univolt";
  case Foxcicle:
    return "Foxcicle";
  case Pyrin:
    return "Pyrin";
  case PyrinNoct:
    return "Pyrin Noct";
  case Reindrix:
    return "Reindrix";
  case Rayhound:
    return "Rayhound";
  case Kitsun:
    return "Kitsun";
  case Dazzi:
    return "Dazzi";
  case Lunaris:
    return "Lunaris";
  case Dinossom:
    return "Dinossom";
  case DinossomLux:
    return "Dinossom Lux";
  case Surfent:
    return "Surfent";
  case SurfentTerra:
    return "Surfent Terra";
  case Maraith:
    return "Maraith";
  case Digtoise:
    return "Digtoise";
  case Tombat:
    return "Tombat";
  case Lovander:
    return "Lovander";
  case Flambelle:
    return "Flambelle";
  case Vanwyrm:
    return "Vanwyrm";
  case VanwyrmCryst:
    return "Vanwyrm Cryst";
  case Bushi:
    return "Bushi";
  case Beakon:
    return "Beakon";
  case Ragnahawk:
    return "Ragnahawk";
  case Katress:
    return "Katress";
  case Wixen:
    return "Wixen";
  case Verdash:
    return "Verdash";
  case Vaelet:
    return "Vaelet";
  case Sibelyx:
    return "Sibelyx";
  case Elphidran:
    return "Elphidran";
  case ElphidranAqua:
    return "Elphidran Aqua";
  case Kelpsea:
    return "Kelpsea";
  case KelpseaIgnis:
    return "Kelpsea Ignis";
  case Azurobe:
    return "Azurobe";
  case Cryolinx:
    return "Cryolinx";
  case Blazehowl:
    return "Blazehowl";
  case BlazehowlNoct:
    return "Blazehowl Noct";
  case Relaxaurus:
    return "Relaxaurus";
  case RelaxaurusLux:
    return "Relaxaurus Lux";
  case Broncherry:
    return "Broncherry";
  case BroncherryAqua:
    return "Broncherry Aqua";
  case Petallia:
    return "Petallia";
  case Reptyro:
    return "Reptyro";
  case IceReptyro:
    return "Ice Reptyro";
  case Kingpaca:
    return "Kingpaca";
  case IceKingpaca:
    return "Ice Kingpaca";
  case Mammorest:
    return "Mammorest";
  case MammorestCryst:
    return "Mammorest Cryst";
  case Wumpo:
    return "Wumpo";
  case WumpoBotan:
    return "Wumpo Botan";
  case Warsect:
    return "Warsect";
  case Fenglope:
    return "Fenglope";
  case Felbat:
    return "Felbat";
  case Quivern:
    return "Quivern";
  case Blazamut:
    return "Blazamut";
  case Helzephyr:
    return "Helzephyr";
  case Astegon:
    return "Astegon";
  case Menasting:
    return "Menasting";
  case Anubis:
    return "Anubis";
  case Jormuntide:
    return "Jormuntide";
  case JormuntideIgnis:
    return "Jormuntide Ignis";
  case Suzaku:
    return "Suzaku";
  case SuzakuAqua:
    return "Suzaku Aqua";
  case Grizzbolt:
    return "Grizzbolt";
  case Lyleen:
    return "Lyleen";
  case LyleenNoct:
    return "Lyleen Noct";
  case Faleris:
    return "Faleris";
  case Orserk:
    return "Orserk";
  case Shadowbeak:
    return "Shadowbeak";
  case Paladius:
    return "Paladius";
  case Necromus:
    return "Necromus";
  case Frostallion:
    return "Frostallion";
  case FrostallionNoct:
    return "Frostallion Noct";
  case Jetragon:
    return "Jetragon";
  default:
    return "?";
  }
}

static constexpr int RankMax = 1500;
static int Rank(ID id) {
  switch (id) {
  case Lamball:
    return 1470;
  case Cattiva:
    return 1460;
  case Chikipi:
    return 1500;
  case Lifmunk:
    return 1430;
  case Foxparks:
    return 1400;
  case Fuack:
    return 1330;
  case Sparkit:
    return 1410;
  case Tanzee:
    return 1250;
  case Rooby:
    return 1155;
  case Pengullet:
    return 1350;
  case Penking:
    return 520;
  case Jolthog:
    return 1370;
  case JolthogCryst:
    return 1360;
  case Gumoss:
    return 1240;
  case GumossSpecial:
    return 1240;
  case Vixy:
    return 1450;
  case Hoocrates:
    return 1390;
  case Teafant:
    return 1490;
  case Depresso:
    return 1380;
  case Cremis:
    return 1455;
  case Daedream:
    return 1230;
  case Rushoar:
    return 1130;
  case Nox:
    return 1180;
  case Fuddler:
    return 1220;
  case Killamari:
    return 1290;
  case Mau:
    return 1480;
  case MauCryst:
    return 1440;
  case Celaray:
    return 870;
  case Direhowl:
    return 1060;
  case Tocotoco:
    return 1340;
  case Flopie:
    return 1280;
  case Mozzarina:
    return 910;
  case Bristla:
    return 1320;
  case Gobfin:
    return 1090;
  case GobfinIgnis:
    return 1100;
  case Hangyu:
    return 1420;
  case HangyuCryst:
    return 1422;
  case Mossanda:
    return 430;
  case MossandaLux:
    return 390;
  case Woolipop:
    return 1190;
  case Caprity:
    return 930;
  case Melpaca:
    return 890;
  case Eikthyrdeer:
    return 920;
  case EikthyrdeerTerra:
    return 900;
  case Nitewing:
    return 420;
  case Ribbuny:
    return 1310;
  case Incineram:
    return 590;
  case IncineramNoct:
    return 580;
  case Cinnamoth:
    return 490;
  case Arsox:
    return 790;
  case Dumud:
    return 895;
  case Cawgnito:
    return 1080;
  case Leezpunk:
    return 1120;
  case LeezpunkIgnis:
    return 1140;
  case Loupmoon:
    return 950;
  case Galeclaw:
    return 1030;
  case Robinquill:
    return 1020;
  case RobinquillTerra:
    return 1000;
  case Gorirat:
    return 1040;
  case Beegarde:
    return 1070;
  case Elizabee:
    return 330;
  case Grintale:
    return 510;
  case Swee:
    return 1300;
  case Sweepa:
    return 410;
  case Chillet:
    return 800;
  case Univolt:
    return 680;
  case Foxcicle:
    return 760;
  case Pyrin:
    return 360;
  case PyrinNoct:
    return 240;
  case Reindrix:
    return 880;
  case Rayhound:
    return 740;
  case Kitsun:
    return 830;
  case Dazzi:
    return 1210;
  case Lunaris:
    return 1110;
  case Dinossom:
    return 820;
  case DinossomLux:
    return 810;
  case Surfent:
    return 560;
  case SurfentTerra:
    return 550;
  case Maraith:
    return 1150;
  case Digtoise:
    return 850;
  case Tombat:
    return 750;
  case Lovander:
    return 940;
  case Flambelle:
    return 1405;
  case Vanwyrm:
    return 660;
  case VanwyrmCryst:
    return 620;
  case Bushi:
    return 640;
  case Beakon:
    return 220;
  case Ragnahawk:
    return 380;
  case Katress:
    return 700;
  case Wixen:
    return 1160;
  case Verdash:
    return 990;
  case Vaelet:
    return 1050;
  case Sibelyx:
    return 450;
  case Elphidran:
    return 540;
  case ElphidranAqua:
    return 530;
  case Kelpsea:
    return 1260;
  case KelpseaIgnis:
    return 1270;
  case Azurobe:
    return 500;
  case Cryolinx:
    return 130;
  case Blazehowl:
    return 710;
  case BlazehowlNoct:
    return 670;
  case Relaxaurus:
    return 280;
  case RelaxaurusLux:
    return 270;
  case Broncherry:
    return 860;
  case BroncherryAqua:
    return 840;
  case Petallia:
    return 780;
  case Reptyro:
    return 320;
  case IceReptyro:
    return 230;
  case Kingpaca:
    return 470;
  case IceKingpaca:
    return 440;
  case Mammorest:
    return 300;
  case MammorestCryst:
    return 290;
  case Wumpo:
    return 460;
  case WumpoBotan:
    return 480;
  case Warsect:
    return 340;
  case Fenglope:
    return 980;
  case Felbat:
    return 1010;
  case Quivern:
    return 350;
  case Blazamut:
    return 10;
  case Helzephyr:
    return 190;
  case Astegon:
    return 150;
  case Menasting:
    return 260;
  case Anubis:
    return 570;
  case Jormuntide:
    return 310;
  case JormuntideIgnis:
    return 315;
  case Suzaku:
    return 50;
  case SuzakuAqua:
    return 30;
  case Grizzbolt:
    return 200;
  case Lyleen:
    return 250;
  case LyleenNoct:
    return 210;
  case Faleris:
    return 370;
  case Orserk:
    return 140;
  case Shadowbeak:
    return 60;
  case Paladius:
    return 80;
  case Necromus:
    return 70;
  case Frostallion:
    return 120;
  case FrostallionNoct:
    return 100;
  case Jetragon:
    return 90;
  default:
    return 9999;
  }
}

static constexpr bool UniqueOnly[LastID] = {
    [RelaxaurusLux] = true, [IncineramNoct] = true,    [MauCryst] = true,
    [VanwyrmCryst] = true,  [EikthyrdeerTerra] = true, [ElphidranAqua] = true,
    [PyrinNoct] = true,     [MammorestCryst] = true,   [MossandaLux] = true,
    [DinossomLux] = true,   [JolthogCryst] = true,     [FrostallionNoct] = true,
    [IceKingpaca] = true,   [LyleenNoct] = true,       [LeezpunkIgnis] = true,
    [BlazehowlNoct] = true, [RobinquillTerra] = true,  [BroncherryAqua] = true,
    [SurfentTerra] = true,  [GobfinIgnis] = true,      [SuzakuAqua] = true,
    [IceReptyro] = true,    [HangyuCryst] = true,      [Lyleen] = true,
    [Faleris] = true,       [Grizzbolt] = true,        [Orserk] = true,
    [Shadowbeak] = true,    [Frostallion] = true,      [Jetragon] = true,
    [Paladius] = true,      [Necromus] = true,         [JormuntideIgnis] = true,
};

static constexpr float MountSpeedMax = 3300;
static constexpr float MountSpeed[LastID] = {
    [Jetragon] = 3300,
    [Necromus] = 1600,                               // Ground (DJ)
    [Frostallion] = 1500,  [FrostallionNoct] = 1500, // Flying
    [Paladius] = 1400,                               // Ground (TJ)
    [Faleris] = 1400,                                // Flying
    [Ragnahawk] = 1300,                              // Flying
    [Pyrin] = 1300,        [PyrinNoct] = 1300,       // Ground
    [Beakon] = 1200,       [Shadowbeak] = 1200,      // Flying
    [Rayhound] = 1150,                               // Ground (DJ)
    [Helzephyr] = 1100,    [Suzaku] = 1100,
    [SuzakuAqua] = 1100,                             // Flying
    [Univolt] = 1100,                                // Ground
    [Fenglope] = 1050,                               // Ground (DJ)
    [Direhowl] = 1050,                               // Ground
    [Quivern] = 950,                                 // Flying
    [Eikthyrdeer] = 900,   [EikthyrdeerTerra] = 900, // Ground (DJ)
    [Blazamut] = 900,      [Blazehowl] = 900,        [BlazehowlNoct] = 900,
    [Kitsun] = 900,                              // Ground
    [Vanwyrm] = 850,       [VanwyrmCryst] = 850, // Flying
    [Astegon] = 800,       [Elphidran] = 800,
    [ElphidranAqua] = 800, // Flying
    [Arsox] = 800,         [Chillet] = 800,          [Grintale] = 800,
    [Maraith] = 800,       [Melpaca] = 800,          [Relaxaurus] = 800,
    [RelaxaurusLux] = 800, // Ground
    [Azurobe] = 800,       // Water
    [Nitewing] = 750,      // Flying
    [Dinossom] = 700,      [DinossomLux] = 700,      [JormuntideIgnis] = 700,
    [Kingpaca] = 700,      [IceKingpaca] = 700,      [Mossanda] = 700,
    [MossandaLux] = 700,   [Reindrix] = 700,
    [Rushoar] = 700,                               // Ground
    [Jormuntide] = 700,                            // Water
    [SurfentTerra] = 650,                          // Ground
    [Surfent] = 650,                               // Water
    [Mammorest] = 600,     [MammorestCryst] = 600, // Ground
    [Grizzbolt] = 550,     [Reptyro] = 550,          [IceReptyro] = 550,
    [Wumpo] = 550,
    [WumpoBotan] = 550, // Ground
    [Broncherry] = 500,    [BroncherryAqua] = 500,
    [Sweepa] = 500, // Ground
};

static constexpr bool Flying[LastID] = {
    [Frostallion] = true, [FrostallionNoct] = true, [Faleris] = true,
    [Ragnahawk] = true,   [Pyrin] = true,           [PyrinNoct] = true,
    [Beakon] = true,      [Shadowbeak] = true,      [Helzephyr] = true,
    [Suzaku] = true,      [SuzakuAqua] = true,      [Quivern] = true,
    [Vanwyrm] = true,     [VanwyrmCryst] = true,    [Astegon] = true,
    [Elphidran] = true,   [ElphidranAqua] = true,   [Nitewing] = true,
};

enum Type {
  NoType,
  Normal,
  Leaf,
  Fire,
  Water,
  Electricity,
  Dark,
  Earth,
  Ice,
  Dragon,
  LastType
};

int TransportSpeed[LastID] = {
    160, 160, 0,   0,   0,   202, 270, 174, 0,   265, 280, 0,   0,   0,
    0,   0,   0,   0,   100, 0,   220, 0,   0,   240, 260, 0,   0,   350,
    0,   0,   250, 0,   250, 120, 120, 250, 250, 275, 275, 0,   0,   0,
    0,   0,   0,   172, 320, 320, 0,   0,   300, 0,   270, 270, 0,   0,
    400, 400, 250, 350, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   300, 315, 0,   0,   0,   0,   0,   0,   270, 460, 140, 475,
    475, 320, 375, 375, 292, 292, 275, 275, 0,   0,   0,   0,   0,   0,
    0,   0,   0,   150, 150, 0,   0,   350, 0,   0,   0,   0,   0,   0,
    150, 150, 110, 0,   0,   470, 0,   450, 0,   0,   480, 0,   0,   0,
    0,   210, 0,   0,   500, 250, 0,   0,   0,   0,   0,   0,
};

struct PalStats {
  Type type1;
  Type type2;
  bool nocturnal;
  int kindling;
  int watering;
  int planting;
  int electric;
  int handiwork;
  int gathering;
  int lumbering;
  int mining;
  int medicine;
  int cooling;
  int transporting;
  int farming;
  int food_requirement;
  int rank;
  int hp;
  int melee;
  int shot;
  int defence;
  int price;
  int stamina;
} static constexpr Stats[LastID] = {
    [Lamball] = {Normal, NoType, false, 0, 0,    0,  0,  1,  0,  0,    0,  0,
                 0,      1,      1,     2, 1470, 70, 70, 70, 70, 1000, 100},
    [Cattiva] = {Normal, NoType, false, 0, 0,    0,  0,  1,  1,  0,    1,  0,
                 0,      1,      0,     2, 1460, 70, 70, 70, 70, 1000, 100},
    [Chikipi] = {Normal, NoType, false, 0, 0,    0,  0,  0,  1,  0,    0,  0,
                 0,      0,      1,     1, 1500, 60, 70, 60, 60, 1000, 100},
    [Lifmunk] = {Leaf, NoType, false, 0, 0,    1,  0,  1,  1,  1,    0,  1,
                 0,    0,      0,     1, 1430, 75, 70, 70, 70, 1010, 100},
    [Foxparks] = {Fire, NoType, false, 1, 0,    0,  0,  0,  0,  0,    0,  0,
                  0,    0,      0,     2, 1400, 65, 70, 75, 70, 1040, 100},
    [Fuack] = {Water, NoType, false, 0, 1,    0,  0,  1,  0,  0,    0,  0,
               0,     1,      0,     2, 1330, 60, 80, 80, 60, 1120, 100},
    [Sparkit] = {Electricity, NoType, false, 0,  0,  0,    1,  1,
                 0,           0,      0,     0,  0,  1,    0,  2,
                 1410,        60,     60,    75, 70, 1030, 100},
    [Tanzee] = {Leaf, NoType, false, 0, 0,    1,  0,   1,  1,  1,    0,  0,
                0,    1,      0,     2, 1250, 80, 100, 70, 70, 1280, 100},
    [Rooby] = {Fire, NoType, false, 1, 0,    0,  0,   0,  0,  0,    0,  0,
               0,    0,      0,     3, 1155, 75, 100, 70, 75, 2950, 100},
    [Pengullet] = {Water, Ice, false, 0, 1,    0,  0,  1,  0,  0,    0,  0,
                   1,     1,   0,     2, 1350, 70, 70, 75, 70, 1080, 100},
    [Penking] = {Water, Ice, false, 0, 2,   0,  0,  2,  0,  0,    2,  0,
                 2,     2,   0,     8, 520, 95, 70, 95, 95, 5410, 100},
    [Jolthog] = {Electricity, NoType, false, 0,  0,  0,    1,  0,
                 0,           0,      0,     0,  0,  0,    0,  2,
                 1370,        70,     70,    75, 70, 1060, 100},
    [JolthogCryst] = {Ice, NoType, false, 0, 0,    0,  0,  0,  0,  0,    0,  0,
                      1,   0,      0,     2, 1360, 70, 70, 75, 80, 1070, 100},
    [Gumoss] = {Leaf, Earth, false, 0, 0,    1,  0,   0,  0,  0,    0,  0,
                0,    0,     0,     1, 1240, 70, 100, 70, 70, 1310, 100},
    [GumossSpecial] = {Leaf, Earth, false, 0,  0,  1,    0,  0,
                       0,    0,     0,     0,  0,  0,    0,  1,
                       1240, 70,    100,   70, 70, 1310, 100},
    [Vixy] = {Normal, NoType, false, 0, 0,    0,  0,  0,  1,  0,    0,  0,
              0,      0,      1,     1, 1450, 70, 70, 70, 70, 1000, 100},
    [Hoocrates] = {Dark, NoType, true, 0, 0,    0,  0,  0,  1,  0,    0,  0,
                   0,    0,      0,    3, 1390, 70, 70, 70, 80, 1050, 100},
    [Teafant] = {Water, NoType, false, 0, 1,    0,  0,  0,  0,  0,    0,  0,
                 0,     0,      0,     2, 1490, 70, 70, 60, 70, 1000, 100},
    [Depresso] = {Dark, NoType, true, 0, 0,    0,  0,  1,  0,  0,    1,  0,
                  0,    1,      0,    2, 1380, 70, 70, 70, 70, 1050, 100},
    [Cremis] = {Normal, NoType, false, 0, 0,    0,  0,   0,  1,  0,    0,  0,
                0,      0,      1,     2, 1455, 70, 100, 70, 75, 1420, 100},
    [Daedream] = {Dark, NoType, true, 0, 0,    0,  0,   1,  1,  0,    0,  0,
                  0,    1,      0,    3, 1230, 70, 100, 75, 60, 1330, 100},
    [Rushoar] = {Earth, NoType, false, 0, 0,    0,  0,   0,  0,  0,    1,  0,
                 0,     0,      0,     3, 1130, 80, 100, 70, 70, 1680, 100},
    [Nox] = {Dark, NoType, false, 0, 0,    0,  0,  0,  1,  0,    0,  0,
             0,    0,      0,     2, 1180, 75, 70, 85, 70, 1480, 100},
    [Fuddler] = {Earth, NoType, false, 0, 0,    0,  0,   1,  0,  0,    1,  0,
                 0,     1,      0,     2, 1220, 65, 100, 80, 50, 1360, 100},
    [Killamari] = {Dark, NoType, true, 0, 0,    0,  0,   0,  1,  0,    0,  0,
                   0,    2,      0,    3, 1290, 60, 100, 60, 70, 1200, 100},
    [Mau] = {Dark, NoType, true, 0, 0,    0,  0,  0,  0,  0,    0,  0,
             0,    0,      1,    1, 1480, 70, 70, 60, 70, 1000, 100},
    [MauCryst] = {Ice, NoType, false, 0, 0,    0,  0,  0,  0,  0,    0,  0,
                  1,   0,      1,     1, 1440, 70, 70, 65, 70, 1010, 100},
    [Celaray] = {Water, NoType, false, 0, 1,   0,  0,   0,  0,  0,    0,  0,
                 0,     1,      0,     3, 870, 80, 100, 70, 80, 2860, 100},
    [Direhowl] = {Normal, NoType, false, 0, 0,    0,  0,   0,  1,  0,    0, 0,
                  0,      0,      0,     3, 1060, 80, 110, 90, 75, 1920, 70},
    [Tocotoco] = {Normal, NoType, false, 0, 0,    0,  0,  0,  1,  0,    0,  0,
                  0,      0,      0,     2, 1340, 60, 80, 75, 70, 1090, 100},
    [Flopie] = {Leaf, NoType, false, 0, 0,    1,  0,   1,  1,  0,    0,  1,
                0,    1,      0,     3, 1280, 75, 100, 65, 70, 1220, 100},
    [Mozzarina] = {Normal, NoType, false, 0, 0,   0,  0,   0,  0,  0,    0,  0,
                   0,      0,      1,     3, 910, 90, 100, 50, 80, 2620, 100},
    [Bristla] = {Leaf, NoType, false, 0, 0,    1,  0,  1,  1,  0,    0,  2,
                 0,    1,      0,     5, 1320, 80, 80, 80, 80, 1140, 100},
    [Gobfin] = {Water, NoType, false, 0, 2,    0,  0,  1,  0,  0,    0,  0,
                0,     1,      0,     3, 1090, 90, 90, 90, 75, 1840, 100},
    [GobfinIgnis] = {Fire, NoType, false, 2, 0,    0,  0,  1,  0,  0,    0,  0,
                     0,    1,      0,     3, 1100, 90, 90, 90, 75, 1800, 100},
    [Hangyu] = {Earth, NoType, false, 0, 0,    0,  0,  1,  1,  0,    0,  0,
                0,     2,      0,     2, 1420, 80, 70, 70, 70, 1020, 100},
    [HangyuCryst] = {Ice, NoType, false, 0, 0,    0,  0,  1,  1,  0,    0,  0,
                     1,   2,      0,     2, 1422, 80, 70, 80, 70, 1020, 100},
    [Mossanda] = {Leaf, NoType, false, 0, 0,   2,   0,   2,  0,  2,    0,  0,
                  0,    3,      0,     5, 430, 100, 100, 90, 90, 6200, 100},
    [MossandaLux] = {Electricity, NoType, false, 0,   0,   0,    2,  2,
                     0,           2,      0,     0,   0,   3,    0,  5,
                     390,         100,    100,   100, 100, 6610, 100},
    [Woolipop] = {Normal, NoType, false, 0, 0,    0,  0,  0,  0,  0,    0,  0,
                  0,      0,      1,     2, 1190, 70, 70, 70, 90, 1450, 100},
    [Caprity] = {Leaf, NoType, false, 0, 0,   2,   0,  0,  0,  0,    0,  0,
                 0,    0,      1,     4, 930, 100, 70, 70, 90, 2510, 100},
    [Melpaca] = {Normal, NoType, false, 0, 0,   0,  0,  0,  0,  0,    0,  0,
                 0,      0,      1,     3, 890, 90, 90, 75, 90, 2740, 100},
    [Eikthyrdeer] = {Normal, NoType, false, 0, 0,   0,  0,  0,  0,  2,    0,  0,
                     0,      0,      0,     5, 920, 95, 70, 80, 80, 2620, 100},
    [EikthyrdeerTerra] = {Earth, NoType, false, 0,  0,  0,    0,  0,
                          0,     2,      0,     0,  0,  0,    0,  5,
                          900,   95,     70,    80, 80, 2680, 100},
    [Nitewing] = {Normal, NoType, false, 0, 0,   0,   0,   0,  2,  0,    0,  0,
                  0,      0,      0,     7, 420, 100, 100, 95, 80, 6300, 100},
    [Ribbuny] = {Normal, NoType, false, 0, 0,    0,  0,   1,  1,  0,    0,  0,
                 0,      1,      0,     2, 1310, 75, 100, 65, 70, 1160, 100},
    [Incineram] = {Fire, Dark, true, 1, 0,   0,  0,   2,   0,  0,    1,  0,
                   0,    2,    0,    4, 590, 95, 150, 100, 85, 4780, 100},
    [IncineramNoct] = {Dark, NoType, true, 0,   0,  0,    0,  2,
                       0,    0,      1,    0,   0,  2,    0,  4,
                       580,  95,     150,  105, 85, 4870, 100},
    [Cinnamoth] = {Leaf, NoType, false, 0, 0,   2,  0,   0,  0,  0,    0,  1,
                   0,    0,      0,     3, 490, 70, 100, 80, 80, 5700, 100},
    [Arsox] = {Fire, NoType, false, 2, 0,   0,  0,   0,  0,  1,    0,  0,
               0,    0,      0,     5, 790, 85, 100, 95, 95, 3520, 100},
    [Dumud] = {Earth, NoType, false, 0, 1,   0,   0,   0,  0,  0,    2,  0,
               0,     1,      0,     4, 895, 100, 100, 70, 95, 4690, 100},
    [Cawgnito] = {Dark, NoType, true, 0, 0,    0,  0,  0,  0,  1,    0,  0,
                  0,    0,      0,    5, 1080, 75, 80, 95, 80, 1840, 100},
    [Leezpunk] = {Dark, NoType, true, 0, 0,    0,  0,  1,  1,  0,    0,  0,
                  0,    1,      0,    3, 1120, 80, 90, 80, 50, 1720, 100},
    [LeezpunkIgnis] = {Fire, NoType, false, 1,  0,  0,    0,  1,
                       1,    0,      0,     0,  0,  1,    0,  3,
                       1140, 80,     90,    80, 50, 1640, 100},
    [Loupmoon] = {Dark, NoType, true, 0, 0,   0,  0,   2,   0,  0,    0,  0,
                  0,    0,      0,    5, 950, 80, 130, 100, 80, 2400, 100},
    [Galeclaw] = {Normal, NoType, false, 0, 0,    0,  0,   0,  2,  0,    0,  0,
                  0,      0,      0,     4, 1030, 75, 120, 85, 60, 2010, 100},
    [Robinquill] = {Leaf, NoType, false, 0, 0,    1,  0,   2,   2,  1,    0,  1,
                    0,    2,      0,     3, 1020, 90, 100, 105, 80, 2050, 100},
    [RobinquillTerra] = {Leaf, Earth, false, 0,   0,  0,    0,  2,
                         2,    1,     0,     1,   0,  2,    0,  3,
                         1000, 90,    100,   105, 80, 2150, 100},
    [Gorirat] = {Normal, NoType, false, 0, 0,    0,  0,   1,  0,  2,    0,  0,
                 0,      3,      0,     3, 1040, 90, 110, 95, 90, 2010, 100},
    [Beegarde] = {Leaf, NoType, false, 0, 0,    1,  0,   1,  1,  1,    0,  1,
                  0,    2,      1,     3, 1070, 80, 100, 90, 90, 1880, 100},
    [Elizabee] = {Leaf, NoType, false, 0, 0,   2,  0,   2,   2,   1,    0,  2,
                  0,    0,      0,     7, 330, 90, 100, 105, 100, 6830, 100},
    [Grintale] = {Normal, NoType, false, 0, 0,   0,   0,   0,  2,  0,    0,  0,
                  0,      0,      0,     4, 510, 110, 100, 80, 80, 5510, 100},
    [Swee] = {Ice, NoType, false, 0, 0,    0,  0,   0,  1,  0,    0,  0,
              1,   0,      0,     2, 1300, 60, 100, 60, 60, 1180, 100},
    [Sweepa] = {Ice, NoType, false, 0, 0,   0,   0,   0,  2,  0,    0,  0,
                2,   0,      0,     3, 410, 100, 100, 90, 90, 6400, 100},
    [Chillet] = {Ice, Dragon, false, 0, 0,   0,  0,   0,  1,  0,    0,  0,
                 1,   0,      0,     3, 800, 90, 100, 80, 80, 3450, 100},
    [Univolt] = {Electricity, NoType, false, 0,   0,   0,    2,  0,
                 0,           1,      0,     0,   0,   0,    0,  5,
                 680,         80,     110,   105, 105, 4280, 100},
    [Foxcicle] = {Ice, NoType, false, 0, 0,   0,  0,   0,  0,   0,    0,  0,
                  2,   0,      0,     3, 760, 90, 100, 95, 105, 3730, 100},
    [Pyrin] = {Fire, NoType, false, 2, 0,   0,   0,   0,  0,  1,    0,  0,
               0,    0,      0,     5, 360, 100, 110, 95, 90, 6720, 100},
    [PyrinNoct] = {Fire, Dark, true, 2, 0,   0,   0,   0,  0,  1,    0,  0,
                   0,    0,    0,    5, 240, 100, 110, 95, 90, 7270, 100},
    [Reindrix] = {Ice, NoType, false, 0, 0,   0,   0,  0,  0,   2,    0,  0,
                  2,   0,      0,     7, 880, 100, 80, 85, 110, 2800, 100},
    [Rayhound] = {Electricity, NoType, false, 0,   0,  0,    2,  0,
                  0,           0,      0,     0,   0,  0,    0,  5,
                  740,         90,     100,   100, 80, 3880, 100},
    [Kitsun] = {Fire, NoType, false, 2, 0,   0,   0,  0,   0,   0,    0,  0,
                0,    0,      0,     4, 830, 100, 70, 115, 100, 3170, 100},
    [Dazzi] = {Electricity, NoType, false, 0,  0,  0,    1,  1,
               0,           0,      0,     0,  0,  1,    0,  2,
               1210,        70,     110,   80, 70, 1390, 100},
    [Lunaris] = {Normal, NoType, false, 0, 0,    0,  0,  3,   1,  0,    0,  0,
                 0,      1,      0,     2, 1110, 90, 80, 100, 90, 1760, 100},
    [Dinossom] = {Leaf, Dragon, false, 0, 0,   2,   0,  0,  0,  2,    0,  0,
                  0,    0,      0,     6, 820, 110, 90, 85, 90, 3240, 100},
    [DinossomLux] = {Electricity, Dragon, false, 0,  0,  0,    2,  0,
                     0,           2,      0,     0,  0,  0,    0,  6,
                     810,         110,    90,    90, 90, 3380, 100},
    [Surfent] = {Water, NoType, false, 0, 2,   0,  0,  0,  0,  0,    0,  0,
                 0,     0,      0,     5, 560, 90, 70, 90, 80, 5050, 100},
    [SurfentTerra] = {Earth, NoType, false, 0,  0,   0,    0,  0,
                      1,     0,      0,     0,  0,   0,    0,  5,
                      550,   90,     70,    90, 100, 5140, 100},
    [Maraith] = {Dark, NoType, true, 0, 0,    0,  0,  0,   2,  0,    1,  0,
                 0,    0,      0,    3, 1150, 75, 50, 105, 80, 1570, 100},
    [Digtoise] = {Earth, NoType, false, 0, 0,   0,  0,  0,  0,   0,    3,  0,
                  0,     0,      0,     5, 850, 80, 80, 95, 120, 2980, 100},
    [Tombat] = {Dark, NoType, true, 0, 0,   0,  0,   0,  2,  0,    2,  0,
                0,    2,      0,    5, 750, 95, 100, 95, 80, 3810, 100},
    [Lovander] = {Normal, NoType, true, 0, 0,   0,   0,  2,  0,  0,    1,  2,
                  0,      2,      0,    5, 940, 120, 70, 70, 70, 2450, 100},
    [Flambelle] = {Fire, NoType, false, 1, 0,    0,  0,   1,  0,  0,    0,  0,
                   0,    1,      1,     2, 1405, 60, 100, 70, 80, 2500, 100},
    [Vanwyrm] = {Fire, Dark, true, 1, 0,   0,  0,   0,   0,  0,    0,  0,
                 0,    3,    0,    6, 660, 90, 100, 115, 90, 4360, 150},
    [VanwyrmCryst] = {Ice, Dark, true, 0, 0,   0,  0,   0,   0,  0,    0,  0,
                      2,   3,    0,    6, 620, 90, 100, 120, 95, 4610, 150},
    [Bushi] = {Fire, NoType, false, 2, 0,   0,  0,   1,   1,  3,    0,  0,
               0,    2,      0,     4, 640, 80, 100, 125, 80, 4520, 100},
    [Beakon] = {Electricity, NoType, false, 0,   0,  0,    2,  0,
                1,           0,      0,     0,   0,  3,    0,  7,
                220,         105,    100,   115, 80, 7490, 160},
    [Ragnahawk] = {Fire, NoType, false, 3, 0,   0,  0,   0,   0,   0,    0,  0,
                   0,    3,      0,     7, 380, 95, 100, 105, 120, 6720, 150},
    [Katress] = {Dark, NoType, true, 0, 0,   0,  0,   2,   0,  0,    0,  2,
                 0,    2,      0,    5, 700, 90, 100, 105, 90, 4120, 100},
    [Wixen] = {Fire, NoType, false, 2, 0,    0,  0,  3,   0,  0,    0,  0,
               0,    2,      0,     5, 1160, 90, 50, 110, 80, 1540, 100},
    [Verdash] = {Leaf, NoType, false, 0, 0,   2,  0,   3,   3,  2,    0,  0,
                 0,    2,      0,     3, 990, 90, 100, 115, 90, 2200, 100},
    [Vaelet] = {Leaf, NoType, false, 0, 0,    2,   0,   2,   2,   0,    0,  3,
                0,    1,      0,     3, 1050, 100, 100, 100, 120, 1960, 100},
    [Sibelyx] = {Ice, NoType, false, 0, 0,   0,   0,  0,  0,   0,    0,  2,
                 2,   0,      1,     5, 450, 110, 90, 90, 100, 5900, 100},
    [Elphidran] = {Dragon, NoType, false, 0, 0,   0,   0,  0,  0,  2,    0,  0,
                   0,      0,      0,     6, 540, 110, 80, 80, 90, 5230, 130},
    [ElphidranAqua] = {Dragon, Water, false, 0,  3,  0,    0,  0,
                       0,      2,     0,     0,  0,  0,    0,  6,
                       530,    115,   80,    80, 95, 5320, 130},
    [Kelpsea] = {Water, NoType, false, 0, 1,    0,  0,   0,  0,  0,    0,  0,
                 0,     0,      0,     1, 1260, 70, 100, 70, 70, 1260, 100},
    [KelpseaIgnis] = {Fire, NoType, false, 1,  0,  0,    0,  0,
                      0,    0,      0,     0,  0,  0,    0,  1,
                      1270, 70,     100,   70, 70, 1240, 100},
    [Azurobe] = {Water, Dragon, false, 0, 3,   0,   0,  0,   0,   0,    0,  0,
                 0,     0,      0,     6, 500, 110, 70, 100, 100, 5600, 100},
    [Cryolinx] = {Ice, NoType, false, 0, 0,   0,   0,   1,   0,   2,    0,  0,
                  3,   0,      0,     7, 130, 100, 140, 100, 110, 8440, 100},
    [Blazehowl] = {Fire, NoType, false, 3, 0,   0,   0,   0,   0,  2,    0,  0,
                   0,    0,      0,     7, 710, 105, 100, 110, 80, 4040, 100},
    [BlazehowlNoct] = {Fire, Dark, true, 3, 0,   0,   0,   0,   0,  2,    0,  0,
                       0,    0,    0,    7, 670, 105, 100, 115, 80, 4360, 100},
    [Relaxaurus] = {Dragon, Water, false, 0,   2,  0,     0,  0,
                    0,      0,     0,     0,   0,  1,     0,  7,
                    280,    110,   110,   100, 70, 10240, 100},
    [RelaxaurusLux] = {Dragon, Electricity, false, 0,   0,  0,     3,  0,
                       0,      0,           0,     0,   0,  1,     0,  7,
                       270,    110,         110,   110, 75, 10380, 100},
    [Broncherry] = {Leaf, NoType, false, 0, 0,   3,   0,  0,  0,   0,    0,  0,
                    0,    0,      0,     7, 860, 120, 80, 90, 100, 2920, 100},
    [BroncherryAqua] = {Leaf, Water, false, 0,  3,   0,    0,  0,
                        0,    0,     0,     0,  0,   0,    0,  7,
                        840,  120,   80,    95, 100, 3110, 100},
    [Petallia] = {Leaf, NoType, false, 0, 0,   3,   0,   2,  2,   0,    0,  2,
                  0,    1,      0,     3, 780, 100, 100, 95, 100, 3590, 100},
    [Reptyro] = {Fire, Earth, false, 3, 0,   0,   0,   0,   0,   0,    3,  0,
                 0,    0,     0,     5, 320, 110, 100, 105, 120, 6940, 100},
    [IceReptyro] = {Ice, Earth, false, 0, 0,   0,   0,   0,   0,   0,    3,  0,
                    3,   0,     0,     5, 230, 110, 100, 105, 130, 7380, 100},
    [Kingpaca] = {Normal, NoType, false, 0, 0,   0,   0,   0,  1,  0,    0,  0,
                  0,      0,      0,     7, 470, 120, 100, 85, 90, 5800, 100},
    [IceKingpaca] = {Ice, NoType, false, 0, 0,   0,   0,   0,  1,  0,    0,  0,
                     3,   0,      0,     7, 440, 120, 100, 85, 90, 6100, 100},
    [Mammorest] = {Leaf, NoType, false, 0, 0,   2,   0,   0,  0,  2,    2,  0,
                   0,    0,      0,     8, 300, 150, 100, 85, 90, 9450, 100},
    [MammorestCryst] = {Ice, NoType, false, 0,  0,  0,    0,  0,
                        0,   2,      2,     0,  2,  0,    0,  8,
                        290, 150,    100,   85, 90, 9580, 100},
    [Wumpo] = {Ice, NoType, false, 0, 0,   0,   0,   2,  0,   3,    0,  0,
               2,   4,      0,     8, 460, 140, 100, 80, 100, 5900, 100},
    [WumpoBotan] = {Leaf, NoType, false, 0, 0,   1,   0,   2,  0,   3,    0,  0,
                    0,    4,      0,     8, 480, 140, 100, 80, 110, 5700, 100},
    [Warsect] = {Earth, Leaf, false, 0, 0,   1,   0,   1,   0,   3,    0,  0,
                 0,     3,    0,     6, 340, 120, 100, 100, 120, 6830, 100},
    [Fenglope] = {Normal, NoType, false, 0, 0,   0,   0,   0,   0,  2,    0,  0,
                  0,      0,      0,     6, 980, 110, 110, 110, 90, 2250, 100},
    [Felbat] = {Dark, NoType, true, 0, 0,    0,   0,   0,   0,   0,    0,  3,
                0,    0,      0,    5, 1010, 100, 100, 105, 110, 2100, 100},
    [Quivern] = {Dragon, NoType, false, 0, 0,   0,   0,   1,   2,   0,    2,  0,
                 0,      3,      0,     4, 350, 105, 100, 100, 100, 6830, 220},
    [Blazamut] = {Fire, NoType, false, 3, 0,  0,   0,   0,   0,   0,     4,  0,
                  0,    0,      0,     9, 10, 100, 150, 125, 120, 10520, 100},
    [Helzephyr] = {Dark, NoType, true, 0, 0,   0,   0,   0,   0,   0,    0,  0,
                   0,    3,      0,    8, 190, 100, 100, 125, 100, 7840, 170},
    [Astegon] = {Dragon, Dark, true, 0, 0,   0,   0,   1,   0,   0,    4,  0,
                 0,      0,    0,    9, 150, 100, 100, 125, 125, 8200, 300},
    [Menasting] = {Dark, Earth, true, 0, 0,   0,   0,   0,   0,   2,    3,  0,
                   0,    0,     0,    7, 260, 100, 100, 100, 130, 7050, 100},
    [Anubis] = {Earth, NoType, false, 0, 0,   0,   0,   4,   0,   0,    3,  0,
                0,     2,      0,     6, 570, 120, 130, 130, 100, 4960, 100},
    [Jormuntide] = {Dragon, Water, false, 0,   4,   0,    0,  0,
                    0,      0,     0,     0,   0,   0,    0,  7,
                    310,    130,   150,   120, 100, 9320, 100},
    [JormuntideIgnis] = {Dragon, Fire, false, 4,   0,   0,    0,  0,
                         0,      0,    0,     0,   0,   0,    0,  7,
                         315,    130,  150,   130, 100, 9500, 100},
    [Suzaku] = {Fire, NoType, false, 3, 0,  0,   0,   0,   0,   0,    0,  0,
                0,    0,      0,     8, 50, 120, 100, 105, 105, 9840, 350},
    [SuzakuAqua] = {Water, NoType, false, 0,   3,   0,     0,  0,
                    0,     0,      0,     0,   0,   0,     0,  8,
                    30,    125,    100,   105, 105, 10110, 350},
    [Grizzbolt] = {Electricity, NoType, false, 0,   0,   0,    3,  2,
                   0,           2,      0,     0,   0,   3,    0,  7,
                   200,         105,    120,   100, 100, 7720, 100},
    [Lyleen] = {Leaf, NoType, false, 0, 0,   4,   0,   3,   2,   0,    0,  3,
                0,    0,      0,     6, 250, 110, 100, 110, 105, 7160, 100},
    [LyleenNoct] = {Dark, NoType, false, 0,   0,   0,    0,  3,
                    2,    0,      0,     3,   0,   0,    0,  6,
                    210,  110,    100,   110, 115, 7610, 100},
    [Faleris] = {Fire, NoType, false, 3, 0,   0,   0,   0,   0,   0,    0,  0,
                 0,    3,      0,     8, 370, 100, 100, 105, 110, 6720, 230},
    [Orserk] = {Dragon, Electricity, false, 0,   0,   0,    4,  2,
                0,      0,           0,     0,   0,   3,    0,  7,
                140,    100,         100,   130, 100, 8320, 100},
    [Shadowbeak] = {Dark, NoType, true, 0, 0,  0,   0,   0,   1,   0,    0,  0,
                    0,    0,      0,    8, 60, 120, 130, 120, 140, 9060, 250},
    [Paladius] = {Normal, NoType, false, 0, 0,  0,   0,   0,   0,   2,    2,  0,
                  0,      0,      0,     9, 80, 130, 110, 120, 145, 8810, 100},
    [Necromus] = {Dark, NoType, true, 0, 0,  0,   0,   0,   0,   2,    2,  0,
                  0,    0,      0,    9, 70, 130, 100, 145, 120, 8930, 100},
    [Frostallion] = {Ice, NoType, false, 0,   0,   0,    0,  0,
                     0,   0,      0,     0,   4,   0,    0,  7,
                     120, 140,    100,   140, 120, 8440, 300},
    [FrostallionNoct] = {Dark, NoType, true, 0,   0,   0,    0,  0,
                         4,    0,      0,    0,   0,   0,    0,  7,
                         100,  140,    100,  140, 135, 8560, 300},
    [Jetragon] = {Dragon, NoType, false, 0, 0,  0,   0,   0,   3,   0,    0,  0,
                  0,      0,      0,     9, 90, 110, 100, 140, 110, 8680, 100},
};
static ID TieBreakOrder[] = {Anubis,
                             Incineram,
                             IncineramNoct,
                             Mau,
                             MauCryst,
                             Rushoar,
                             Lifmunk,
                             Tocotoco,
                             Eikthyrdeer,
                             EikthyrdeerTerra,
                             Digtoise,
                             Galeclaw,
                             Grizzbolt,
                             Teafant,
                             Direhowl,
                             Gorirat,
                             Jolthog,
                             JolthogCryst,
                             Univolt,
                             Foxparks,
                             Bristla,
                             Lunaris,
                             Pengullet,
                             Dazzi,
                             Gobfin,
                             GobfinIgnis,
                             Lamball,
                             Jormuntide,
                             JormuntideIgnis,
                             Loupmoon,
                             Hangyu,
                             HangyuCryst,
                             Suzaku,
                             SuzakuAqua,
                             Pyrin,
                             PyrinNoct,
                             Elphidran,
                             ElphidranAqua,
                             Woolipop,
                             Cryolinx,
                             Melpaca,
                             Surfent,
                             SurfentTerra,
                             Cawgnito,
                             Azurobe,
                             Cattiva,
                             Depresso,
                             Fenglope,
                             Reptyro,
                             IceReptyro,
                             Maraith,
                             Robinquill,
                             RobinquillTerra,
                             Relaxaurus,
                             RelaxaurusLux,
                             Kitsun,
                             Leezpunk,
                             LeezpunkIgnis,
                             Fuack,
                             Vanwyrm,
                             VanwyrmCryst,
                             Chikipi,
                             Dinossom,
                             DinossomLux,
                             Sparkit,
                             Frostallion,
                             FrostallionNoct,
                             Mammorest,
                             MammorestCryst,
                             Felbat,
                             Broncherry,
                             BroncherryAqua,
                             Faleris,
                             Blazamut,
                             Caprity,
                             Reindrix,
                             Shadowbeak,
                             Sibelyx,
                             Vixy,
                             Wixen,
                             Lovander,
                             Hoocrates,
                             Kelpsea,
                             KelpseaIgnis,
                             Killamari,
                             Mozzarina,
                             Wumpo,
                             WumpoBotan,
                             Vaelet,
                             Nitewing,
                             Flopie,
                             Lyleen,
                             LyleenNoct,
                             Elizabee,
                             Beegarde,
                             Tombat,
                             Mossanda,
                             MossandaLux,
                             Arsox,
                             Rayhound,
                             Fuddler,
                             Astegon,
                             Verdash,
                             Foxcicle,
                             Jetragon,
                             Daedream,
                             Tanzee,
                             Blazehowl,
                             BlazehowlNoct,
                             Kingpaca,
                             IceKingpaca,
                             Gumoss,
                             GumossSpecial,
                             Swee,
                             Sweepa,
                             Katress,
                             Ribbuny,
                             Beakon,
                             Warsect,
                             Paladius,
                             Nox,
                             Penking,
                             Chillet,
                             Quivern,
                             Helzephyr,
                             Ragnahawk,
                             Bushi,
                             Celaray,
                             Necromus,
                             Petallia,
                             Grintale,
                             Cinnamoth,
                             Menasting,
                             Orserk,
                             Cremis,
                             Dumud,
                             Flambelle,
                             Rooby};

static ID RankToID(int rank) {
  ID best_id = Lamball;
  int best_rank = Rank(best_id);
  for (ID id : TieBreakOrder) {
    if (UniqueOnly[id]) {
      continue;
    }
    int id_rank = Rank(id);
    if (abs(id_rank - rank) < abs(best_rank - rank)) {
      best_rank = id_rank;
      best_id = id;
    }
  }
  return best_id;
}

struct Pal {
  ID id = Lamball;
  Gender gender = Male;
  Traits traits = {NoTrait, NoTrait, NoTrait, NoTrait};
  Pal() {}
  Pal(const Pal &other)
      : id(other.id), gender(other.gender), traits(other.traits) {}
  Pal(ID id_arg, Gender gender_arg, Traits traits_arg)
      : id(id_arg), gender(gender_arg), traits(traits_arg) {
    // Remove duplicate traits
    for (int a = 1; a < traits.size(); ++a) {
      for (int b = 0; b < a; ++b) {
        if (traits[a] == traits[b]) {
          traits[b] = NoTrait;
          break;
        }
      }
    }
    // Sort traits
    sort(traits.begin(), traits.end());
  }
  Pal &operator=(const Pal &other) {
    id = other.id;
    gender = other.gender;
    traits = other.traits;
    return *this;
  }
  string ToStr() const {
    char buf[100];
    snprintf(buf, 100, "%s %s", ::ToStr(id), ::ToStr(gender));
    string ret{buf};
    bool has_traits = false;
    for (auto t : traits)
      if (t != NoTrait)
        has_traits = true;
    if (has_traits) {
      ret += " (";
      for (auto t : traits) {
        if (t == NoTrait)
          continue;
        ret += ::ToStr(t);
        ret += ' ';
      }
      ret.pop_back();
      ret += ')';
    }

    return ret;
  }
  bool operator==(const Pal &other) const {
    return id == other.id && gender == other.gender && traits == other.traits;
  }
  auto operator<=>(const Pal &other) const = default;
};

namespace std {
template <> struct hash<Pal> {
  size_t operator()(const Pal &pal) const noexcept {
    uint64_t ret = 0;
    __builtin_memcpy(&ret, &pal, sizeof(Pal));
    if constexpr (sizeof(size_t) == 8) {
      return ret;
    } else {
      return ret ^ (ret >> 32);
    }
  }
};
} // namespace std

extern "C" {
int IDCount() { return LastID; }
const char *IDName(int i) { return ToStr(static_cast<ID>(i)); }
}