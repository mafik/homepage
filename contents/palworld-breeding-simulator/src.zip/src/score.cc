#include "rooster.cc"

float SpeedMultiplier(Pal pal) {
  float multiplier = 1;
  for (auto t : pal.traits) {
    if (t == NoTrait)
      continue;
    else if (t == Swift)
      multiplier += 0.3;
    else if (t == Runner)
      multiplier += 0.2;
    else if (t == Legend)
      multiplier += 0.15;
    else if (t == Nimble)
      multiplier += 0.1;
  }
  return multiplier;
}

float ScoreMount(Pal pal) {
  float score = MountSpeed[pal.id] * (Flying[pal.id] ? 1.0 : 0.5);
  return score * SpeedMultiplier(pal);
}

float WorkSpeed(Pal pal) {
  float work_speed = 1;
  for (auto t : pal.traits) {
    if (t == Artisan) {
      work_speed += 0.5;
    } else if (t == WorkSlave) {
      work_speed += 0.3;
    } else if (t == Serious) {
      work_speed += 0.2;
    } else if (t == Lucky) {
      work_speed += 0.15;
    } else if (t == Conceited) {
      work_speed += 0.1;
    } else if (t == Musclehead) {
      work_speed -= 0.5;
    } else if (t == Clumsy) {
      work_speed -= 0.1;
    } else if (t == Hooligan) {
      work_speed -= 0.1;
    } else if (t == Slacker) {
      work_speed -= 0.3;
    }
  }
  return work_speed;
}

float HungerMultiplier(Pal pal) {
  float multiplier = 1;
  for (auto t : pal.traits) {
    if (t == DaintyEater) {
      multiplier -= 0.1;
    } else if (t == BottomlessStomach) {
      multiplier += 0.15;
    } else if (t == DietLover) {
      multiplier -= 0.15;
    } else if (t == Glutton) {
      multiplier += 0.1;
    }
  }
  return multiplier;
}

float Hunger(Pal pal) {
  return Stats[pal.id].food_requirement * HungerMultiplier(pal);
}

float Sanity(Pal pal) {
  float sanity = 1;
  for (auto t : pal.traits) {
    if (t == Destructive) {
      sanity -= 0.15;
    } else if (t == PositiveThinker) {
      sanity += 0.1;
    } else if (t == Unstable) {
      sanity -= 0.1;
    } else if (t == Workaholic) {
      sanity += 0.15;
    }
  }
  return sanity;
}

float ScoreKindling(Pal pal) { return Stats[pal.id].kindling * WorkSpeed(pal); }
float ScoreWatering(Pal pal) { return Stats[pal.id].watering * WorkSpeed(pal); }
float ScorePlanting(Pal pal) { return Stats[pal.id].planting * WorkSpeed(pal); }
float ScoreElectric(Pal pal) { return Stats[pal.id].electric * WorkSpeed(pal); }
float ScoreHandiwork(Pal pal) {
  return Stats[pal.id].handiwork * WorkSpeed(pal);
}
float ScoreGathering(Pal pal) {
  return Stats[pal.id].gathering * WorkSpeed(pal);
}
float ScoreLumbering(Pal pal) {
  return Stats[pal.id].lumbering * WorkSpeed(pal);
}
float ScoreMining(Pal pal) { return Stats[pal.id].mining * WorkSpeed(pal); }
float ScoreMedicine(Pal pal) { return Stats[pal.id].medicine * WorkSpeed(pal); }
float ScoreCooling(Pal pal) { return Stats[pal.id].cooling * WorkSpeed(pal); }

float ScoreTransporting(Pal pal) {
  return Stats[pal.id].transporting * TransportSpeed[pal.id] *
         SpeedMultiplier(pal);
}

float WoolProduction[LastID] = {
    [Lamball] = 1.0f,
    [Cremis] = 2.0f,
    [Melpaca] = 2.0f,
};

float ScoreWool(Pal pal) {
  return WoolProduction[pal.id] * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreEggs(Pal pal) {
  return (pal.id == Chikipi ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float GoldProduction[LastID] = {
    [Vixy] = 1.0f,
    [Mau] = 2.0f,
    [MauCryst] = 2.0f,
};

float ScoreGold(Pal pal) {
  return GoldProduction[pal.id] * Sanity(pal) / HungerMultiplier(pal);
}

float ScorePalspheres(Pal pal) {
  return (pal.id == Vixy ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreMilk(Pal pal) {
  return (pal.id == Mozzarina ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreCottonCandy(Pal pal) {
  return (pal.id == Woolipop ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreBerry(Pal pal) {
  return (pal.id == Caprity ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreHoney(Pal pal) {
  return (pal.id == Beegarde ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreFlameOrgan(Pal pal) {
  return (pal.id == Flambelle ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}

float ScoreHighQualityCloth(Pal pal) {
  return (pal.id == Sibelyx ? 1 : 0) * Sanity(pal) / HungerMultiplier(pal);
}