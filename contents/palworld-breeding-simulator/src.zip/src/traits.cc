
#include <array>
#include <cstdint>
#include <cstdlib>

enum Trait : uint8_t {
  NoTrait,
  Abnormal,          //	10% less damage from incoming Neutral type attacks
  Aggressive,        //	Attack increases by 10%Defense decreases by 10%
  Artisan,           //	Work speed increases by 50%
  Brittle,           //	Defense decreases by 20%
  BurlyBody,         // Defense increased by 20%
  BloodOfTheDragon,  // 10% increase to damage output when using Dragon type
                     // attacks
  BotanicalBarrier,  //	10% less damage from incoming Grass type attacks
  BottomlessStomach, // 	Hunger increases 15% faster
  Brave,             //	Attack increases by 10%
  Capacitor,   //	10% increase to damage output when using Electric type attacks
  Cheery,      //	10% less damage from incoming Dark type attacks
  Clumsy,      //	Work speed decreases by 10%
  Coldblooded, //	10% increase to damage output when using Ice type
               // attacks
  Coward,      //	Attack decreases by 10%
  Conceited,   //	Work Speed increases by 10%Defense decreases by 10%
  DaintyEater, // 	Hunger decreases 10% slower
  DietLover,   // 	Hunger decrease is 15% less likely
  Destructive, //	Sanity decreases 15% faster
  DivineDragon,        // 	20% increase to damage output when using Dragon type
                       // attacks
  Downtrodden,         //	Defense decreases by 10%
  Dragonkiller,        //	10% less damage from incoming Dragon type attacks
  EarthEmperor,        // 	20% increase to damage output when using Ground type
                       // attacks
  EarthquakeResistant, // 	10% less damage from incoming Ground type
                       // attacks
  Ferocious,           //	Attack increases by 20%
  FragrantFoliage,     // 	10% increase to damage output when using Grass type
                       // attacks
  Glutton,             //	Hunger increases 10% faster
  HardSkin,            // 	Defense increases by 10%
  HeatedBody,          // 	10% less damage from incoming Ice type attacks
  Hooligan,            //	Attack increases by 15%Work speed decreases by 10%
  Hydromaniac,         //	10% increase to damage output when using Water type
                       // attacks
  IceEmperor,          // 	20% increase to damage output when using Ice type
                       // attacks
  InsulatedBody,       // 	10% less damage from incoming Ice type attacks
  Legend, //	Attack increases by 20%Defense increases by 20%Movement speed
          // increases by 15%
  LoggingForeman,       // 	Players Logging efficiency increases by 25%
  LordOfDarkness,       // 	20% increase to damage output when using Dark type
                        // attacks
  LordOfTheSea,         // 	20% increase to damage output when using Water type
                        // attacks
  Lucky,                //	Work speed increases by 15%Attack increases by 20%
  Masochist,            //	Defense increases by 15%Attack decreases by 15%
  MineForeman,          // 	Players Mining efficiency increases by 25%
  MotivationalLeader,   // 	Players movement speed increases by 25%
  Musclehead,           //	Attack increases by 30%Work speed decreases by 50%
  Nimble,               //	Movement speed increases by 10%
  Pacifist,             //	Attack decreases by 20%
  PositiveThinker,      // 	Sanity decreases 10% slower
  PowerOfGaia,          // 	10% increase to damage output when using Ground type
                        // attacks
  Pyromaniac,           //	10% increase to damage output when using Fire type
                        // attacks
  Runner,               //	Movement speed increases by 20%
  Sadist,               //	Attack increases by 15%Defense decreases by 15%
  Serious,              //	Work speed increases by 20%
  SuntanLover,          // 	10% less damage from incoming Fire type attacks
  Swift,                //	Movement speed increases by 30%
  StrongholdStrategist, // 	Players defense increases by 10%
  Slacker,              //	Work speed decreases by 30%
  Unstable,             //	Sanity decreases 10% faster
  Vanguard,             //	Players attack increases by 10%
  VeilOfDarkness,       // 	10% increase to damage output when using Dark type
                        // attacks
  Waterproof,           //	10% less damage from incoming Water type attacks
  Workaholic,           //	Sanity decreases 15% slower
  WorkSlave,            // 	Work speed increases by 30%Attack decreases by 30%
  ZenMind, //	10% increase to damage output when using Neutral type attacks
  LastTrait,
};

static bool BadTraits[LastTrait] = {[Abnormal] = true,
                                    [Aggressive] = true,
                                    [Brittle] = true,
                                    [BurlyBody] = true,
                                    [BloodOfTheDragon] = true,
                                    [BotanicalBarrier] = true,
                                    [BottomlessStomach] = true,
                                    [Brave] = true,
                                    [Capacitor] = true,
                                    [Cheery] = true,
                                    [Clumsy] = true,
                                    [Coldblooded] = true,
                                    [Coward] = true,
                                    [Destructive] = true,
                                    [Downtrodden] = true,
                                    [Dragonkiller] = true,
                                    [EarthquakeResistant] = true,
                                    [FragrantFoliage] = true,
                                    [Glutton] = true,
                                    [HardSkin] = true,
                                    [HeatedBody] = true,
                                    [Hooligan] = true,
                                    [Hydromaniac] = true,
                                    [InsulatedBody] = true,
                                    [LoggingForeman] = true,
                                    [Masochist] = true,
                                    [MineForeman] = true,
                                    [MotivationalLeader] = true,
                                    [Pacifist] = true,
                                    [PowerOfGaia] = true,
                                    [Pyromaniac] = true,
                                    [Sadist] = true,
                                    [SuntanLover] = true,
                                    [StrongholdStrategist] = true,
                                    [Slacker] = true,
                                    [Unstable] = true,
                                    [Vanguard] = true,
                                    [VeilOfDarkness] = true,
                                    [Waterproof] = true,
                                    [ZenMind] = true};

static Trait kRandomTraits[] = {
    Abnormal,
    Aggressive,
    Artisan,
    Brittle,
    BurlyBody,
    BloodOfTheDragon,
    BotanicalBarrier,
    BottomlessStomach,
    Brave,
    Capacitor,
    Cheery,
    Clumsy,
    Coldblooded,
    Coward,
    Conceited,
    DaintyEater,
    DietLover,
    Destructive,
    Downtrodden,
    Dragonkiller,
    EarthquakeResistant,
    Ferocious,
    FragrantFoliage,
    Glutton,
    HardSkin,
    HeatedBody,
    Hooligan,
    Hydromaniac,
    InsulatedBody,
    LoggingForeman,
    Masochist,
    MineForeman,
    MotivationalLeader,
    Musclehead,
    Nimble,
    Pacifist,
    PositiveThinker,
    PowerOfGaia,
    Pyromaniac,
    Runner,
    Sadist,
    Serious,
    SuntanLover,
    Swift,
    StrongholdStrategist,
    Slacker,
    Unstable,
    Vanguard,
    VeilOfDarkness,
    Waterproof,
    Workaholic,
    WorkSlave,
    ZenMind,

};

static Trait RandomTrait() {
  return kRandomTraits[rand() % sizeof(kRandomTraits)];
}

static const char *ToStr(Trait a) {
  switch (a) {
  case NoTrait:
    return "-";
  case Abnormal:
    return "Abnormal";
  case Aggressive:
    return "Aggressive";
  case Artisan:
    return "Artisan";
  case Brittle:
    return "Brittle";
  case BurlyBody:
    return "Burly Body";
  case BloodOfTheDragon:
    return "Blood of the Dragon";
  case BotanicalBarrier:
    return "Botanical Barrier";
  case BottomlessStomach:
    return "Bottomless Stomach";
  case Brave:
    return "Brave";
  case Capacitor:
    return "Capacitor";
  case Cheery:
    return "Cheery";
  case Clumsy:
    return "Clumsy";
  case Coldblooded:
    return "Coldblooded";
  case Coward:
    return "Coward";
  case Conceited:
    return "Conceited";
  case DaintyEater:
    return "Dainty Eater";
  case DietLover:
    return "Diet Lover";
  case Destructive:
    return "Destructive";
  case DivineDragon:
    return "Divine Dragon";
  case Downtrodden:
    return "Downtrodden";
  case Dragonkiller:
    return "Dragonkiller";
  case EarthEmperor:
    return "Earth Emperor";
  case EarthquakeResistant:
    return "Earthquake Resistant";
  case Ferocious:
    return "Ferocious";
  case FragrantFoliage:
    return "Fragrant Foliage";
  case Glutton:
    return "Glutton";
  case HardSkin:
    return "Hard Skin";
  case HeatedBody:
    return "Heated Body";
  case Hooligan:
    return "Hooligan";
  case Hydromaniac:
    return "Hydromaniac";
  case IceEmperor:
    return "Ice Emperor";
  case InsulatedBody:
    return "Insulated Body";
  case Legend:
    return "Legend";
  case LoggingForeman:
    return "Logging Foreman";
  case LordOfDarkness:
    return "Lord of Darkness";
  case LordOfTheSea:
    return "Lord of the Sea";
  case Lucky:
    return "Lucky";
  case Masochist:
    return "Masochist";
  case MineForeman:
    return "Mine Foreman";
  case MotivationalLeader:
    return "Motivational Leader";
  case Musclehead:
    return "Musclehead";
  case Nimble:
    return "Nimble";
  case Pacifist:
    return "Pacifist";
  case PositiveThinker:
    return "Positive Thinker";
  case PowerOfGaia:
    return "Power of Gaia";
  case Pyromaniac:
    return "Pyromaniac";
  case Runner:
    return "Runner";
  case Sadist:
    return "Sadist";
  case Serious:
    return "Serious";
  case SuntanLover:
    return "Suntan Lover";
  case Swift:
    return "Swift";
  case StrongholdStrategist:
    return "Stronghold Strategist";
  case Slacker:
    return "Slacker";
  case Unstable:
    return "Unstable";
  case Vanguard:
    return "Vanguard";
  case VeilOfDarkness:
    return "Veil of Darkness";
  case Waterproof:
    return "Waterproof";
  case Workaholic:
    return "Workaholic";
  case WorkSlave:
    return "Work Slave";
  case ZenMind:
    return "Zen Mind";
  default:
    return "?";
  }
}

using Traits = std::array<Trait, 4>;

static Trait kBestTraitsForWorker[] = {
    Artisan,   // +50% work speed
    WorkSlave, // +30% work speed
    Serious,   // +20% work speed
    Lucky,     // +15% work speed
    Conceited, // +10% work speed
};

static Trait kBestTraitsForTransporting[] = {Swift, Runner, Legend, Nimble};

static Trait kBestTraitsForMount[] = {
    Swift,  // +30% speed
    Runner, // +20% speed
    Legend, // +15% speed
    Nimble, // +10% speed
};

static Trait kBestTraitsForFarming[] = {
    Workaholic,
    PositiveThinker,
    DietLover,
    DaintyEater,
};

static Trait kBestTraitsForCombat[] = {
    Legend,     // +20% attack/defense
    Musclehead, // +30% attack
    Ferocious,  // +20% attack
    Lucky,      // +15% attack
};

extern "C" {
int TraitCount() { return LastTrait; }
const char *TraitName(int i) { return ToStr(static_cast<Trait>(i)); }
}
